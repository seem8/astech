Last updated June 23, 2005 by Hopalong

Customs:
You can unzip the files and hand edit a unit
Copy a Heavy Metal Pro file into this folder
The Drawing Board free designer with newest patch, save as "xml" format
To match a unit with a gif (picture) you'll need to edit the "mechset" in mex folder

Mechs:
Changed some mech names (MFUK) when they are duplicated
Blackjack/Ostroc/Scorpion (3050) have double heatsinks (this is official)
Shogun SHG-2E is a lvl2 mech

Vehs:
armor type: 0=standard 1=ferrofibrous
engine type: 0=fusion 1=ICE 2=xl

Condor Multi-Purpose Tank has hover movement, removed a front MG
J-27 and Mobile Longtom have trailers "combined" into 1 vehicle
Badger and Bandit are omnivehicles and are lvl2 tech
Revised Hover Tank and Weapons Carrier included