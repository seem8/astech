========================
JJJJAAAAAKKKKKKEEEEEEE'S	-=Ver=-
BIG MAP PACK FOR MEGAMEK	-=1.4=-
========================

--June 7th 2004 Version!!--

Rip out all of your old maps that start with jake-*.board
and put these in their places! I've fixed old ones, made
new ones, added more maps for favored old sets, and made 
everything prettier and smoother (I think!). Enjoy cats!

	NEW MAPS INCLUDE:

		Firebase! Defend the firebase! Best on double-blind!
		TankRush! Fight with lvl1 AC5 tanks, etc, you'll love it!
		Ewoklandia! Fight it up in ze forests!
		WideBlueRiver! Town & country rip-up!
		IceBridge! Who will cross? Good for lvl1 conventional, also!
		ShakenNotStirred! Underwater maze fighting!
		OnTheRocks! Stripped down underwater-ness!
		Skitrip & Snowdrifts! Plan your winter vacation!


--What ISS thIs THinG??--

These are boards/maps for use with MegaMek:
http://megamek.sourceforge.net


--INSTALLaaaaaaation!!!--

Unzip these to your megamek/data/boards directory for use.
If they don't show up when you're selecting the maps, make
sure that you've put them in the right place! :}


--WhaT'S iNCLUDED!!--

In this zip I include these nonstandards:
	25x25 Breaker (infighting with a twist-- see it to believe!)
	25x25 Crater (like a Trial of Bloodright thing)
	25x25 OnTheRocks (first underwater combat map, ocean floor simple)
	25x25 ShakenNotStirred (second underwater map, like maze but U-W!)
	35x35 IceBridge (who will cross the icebridge?)
	35x35 Syreen (a lot like "Plateaus" in MechW2 but more complex)
	35x35 Syreen2 (a better version -- on an ice world)
	35x35 WideBlueRiver (town & country with a river, good lance vs)
	35x45 Firebase (35x45! attacker from S, defender places where desires)
	45x45 King of the Hill (koth) (a KotH map for Hurlbut!)
	45x45 TankRush (fairly open, some hills, trees, good for tank combat!)

In this zip I include these standard sized maps:
	Badlands1-4 (perfect company/lance skirmish maps)
	Beach+Beachwater1-2 (see setup)
	Brewery1-2 (more like a Sol7 map, sort of a shattered hellhole)
	Cannonball1-4 (my favorite, dried riverbeds with trees!)
	CityNewOslo1-5 (New Oslo city maps, styling)
	CityRhods1-3 (bombed out city)
	Dam1-6 (see setup, beautiful when set up right)
	Dunes1-3 (desert rat pack)
	Estuary1-4 (plenty of water, small islands, land bridges)
	Ewoklandia1-4 (heavily wooded, some trees real, some not)
	FaultHills1-3 (rather like badlands but less open)
	Garden1-3+GardenToo1-3 (my second favorite, just check it)
	Highway1-3 (special setup, good for ambush missions)
	IslandHop1-4 (cliff islands, need jumpers or hovercraft)
	Maze1-4+MazeToo1-2 (like "Maze" in MechW2)
	Pagoda1-7 (mission maps, notice 4-7's specialized sectors)
	Plateau1-3 (plateaus, this time around they're fixed!)
	Poppyseed1-2 (residential/commercial area in highlands)
	Rosehills1-3 (special setup, base vs base style)
	Sands1-5 (arid/inland California type, with a Castle Brian!)
	Skitrip1-4 (snowy, some peaks, simple icey terrain)
	Snowdrifts1-4 (very flat snow plains type mapset)
	Trenches1-3 (plays like badlands or faulthills but inverted)
	Waterpolo1-4 (a classic! riverbed through dry mountains map)


--NotEs on SPECIAL MAPS!!--

Files with (spec) in their title must be set up in
a special way when playing (I forgot that you could
make nonstandard size boards, so eh...) --

	Rosehills - make 1x3 and put the boards down from
     	         west to east in order

	Dam - make 3x2 and put the boards down like so
		 1 2
		 3 4
		 5 6

	Beach - make 2x? and make sure that:
		 a. beachwater is NORTH of beach
		 b. beach1+2 should alternate to form a coast
		 c. when these are rotated, reverse order
	
	Highway - follow the Rosehills method


--Notes on NONstandards!!--

There are a few nonstandard sized boards for special purposes.
When loading a map in MM, set board sizes to:
45x45/35x35/25x25 -- for various Solaris-style/KotH maps. These
are the 'standard' nonstandard (grin) sizes I make my maps on.
Real big ones might be 55x55 or 65x65 in the future.


--OtHeR NoteSSSS!!--

The newest versions of MegaMekDev (highly recommended!) have
cute new gadgets like temperature control! Perfect for those hot
desert maps and those lovely icey cold maps I've created!


--CONTACT & creds--

Jake Murrow
email: cloudburst@earthlink.net
msn: willowbeard@hotmail.com
cbt messageboards: Seoc
megameknet lvl1: Seoc (Steiner)

By the way, these maps are mine. Feel free to distribute them
wherever you like as long as credit is given, and this readme
file stays with them. For that matter, just don't tinker with
the zipfile. :} But give me a buzz if you put em up on your
site! I love ego boosts!

Also! Thanks to the MM people for making such a superlative
game and map editor! I love it!