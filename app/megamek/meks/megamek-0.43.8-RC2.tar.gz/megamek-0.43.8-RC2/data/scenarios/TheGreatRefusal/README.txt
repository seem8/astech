These Scenarios allow players to recreate the Great Refusal held on Strana Mechty, where the elite units of Task force Serpeant squared off against the Crusader Clans to determine the fate of the invasion of the Innersphere.

All of these scenarios were designed for MegaMek version 29 or greater and all have been playtested both against human and bot opponents. Be aware that throughout these battles both sides abided to Clan Honour Level 2 as described on page five of "The Twilight of the Clans" Scenario pack.

The Historical Results of the battles were...

Battle 1: Clan Smoke Jaguar (Lose) V Federated Commonwealth (Win)
Battle 2: Clan Wolf (Draw) V St Ives Compact (Draw)  
Battle 3: Clan Blood Spirit (Lose) V Draconis Combine (Win) 
Battle 4: Clan Jade Falcon (Win) V Comstar (Lose)  
Battle 5: Clan Star Adder (Win) V Free Worlds League (Lose)  
Battle 6: Clan Fire Mandrill (Lose) V Capellan Confederation (Win)
Battle 7: Clan Hells Horses (Lose) V Free Rasalhague Republic (Win) 
Battle 8: Clan Ice Hellion (Lose) V Clan Nova Cat (Win)

Wallis DelVillar, 5th August 2003.