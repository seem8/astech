Fontname: Battletech Oldstyle
Created by: Jason M. Knight (aka Deathshadow)
http://www.classicbattletech.com/truetype/bt_oldstyle.zip

This file contains a recreation of the fonts used in the Classic Battletech Logo on products from 1984 to 1991. Upper and Lower case letters are identical except for the letter R, which appears differently on the Battleforce products than it does on the others. The lower case R is that used on Battleforce, while the upper case version is that used on Mechwarrior and Succession Wars.

Additionally, the following 5 wingdings are available:

CHR  ASCII  IMAGE
 !    33    House Davion
 @    64    House Kurita
 #    35    House Steiner
 $    36    House Liao
 %    37    House Marik

This file is free for non-profit and recreational use, and is not to be used on commercial products without the permission of Fantasy Productions. Any future fonts will be archived at http://www.classicbattletech.com/truetype

Original contents of ClassicBattletech.com � 2001 Fantasy Productions, LLC.

Battletech, Mechwarrior and Battlemech are registered trademarks of WizKids, LLC. All Rights Reserved.� 2001 WizKids, LLC.
